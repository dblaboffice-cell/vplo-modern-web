(() => {
  'use strict';
  const button = document.querySelector('.menu-btn');
  const panel = document.querySelector('.mobile-panel');
  const desktopMenu = document.querySelector('.desktop-nav .mod-menu');
  const mobileInner = document.querySelector('.mobile-panel-inner');
  if (!button || !panel || !mobileInner) return;

  if (desktopMenu) {
    const mobileMenu = desktopMenu.cloneNode(true);
    mobileMenu.classList.add('mobile-menu');
    mobileInner.appendChild(mobileMenu);
  }

  const setOpen = (open) => {
    panel.hidden = !open;
    button.setAttribute('aria-expanded', String(open));
    button.classList.toggle('is-open', open);
  };
  button.addEventListener('click', () => setOpen(panel.hidden));
  panel.addEventListener('click', (event) => {
    if (event.target.closest('a')) setOpen(false);
  });
  window.addEventListener('resize', () => {
    if (window.innerWidth > 860) setOpen(false);
  });
})();
