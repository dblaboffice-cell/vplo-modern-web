<?php
defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;

$e = static fn ($value): string => htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
$hasSocial = $params->get('instagram_url') || $params->get('tiktok_url');

if (!$items && !$hasSocial) {
    return;
}
?>
<section class="home-updates">
  <div class="container home-updates-grid">
    <?php foreach ($items as $item) : ?>
      <?php $image = $item->images['image_intro'] ?? ''; $alt = $item->images['image_intro_alt'] ?? $item->title; ?>
      <a class="home-card news" href="<?= $e($item->link) ?>">
        <?php if ($image) : ?><img src="<?= $e($image) ?>" alt="<?= $e($alt) ?>"><?php endif; ?>
        <span><b><?= $e($params->get('news_label')) ?></b><strong><?= $e($item->title) ?></strong><small><?= $e(HTMLHelper::_('date', $item->publish_up, 'd MMMM Y')) ?><?= $params->get('news_meta_suffix') ? ' · ' . $e($params->get('news_meta_suffix')) : '' ?></small><em><?= $e($params->get('news_link_label')) ?></em></span>
      </a>
    <?php endforeach; ?>
    <?php if ($params->get('instagram_url')) : ?>
      <a class="home-card instagram" href="<?= $e($params->get('instagram_url')) ?>" target="_blank" rel="noopener"><b><?= $e($params->get('instagram_label')) ?></b><h2><?= $e($params->get('instagram_handle')) ?></h2><p><?= $e($params->get('instagram_text')) ?></p><strong><?= $e($params->get('instagram_link_label')) ?></strong></a>
    <?php endif; ?>
    <?php if ($params->get('tiktok_url')) : ?>
      <a class="home-card tiktok" href="<?= $e($params->get('tiktok_url')) ?>" target="_blank" rel="noopener"><b><?= $e($params->get('tiktok_label')) ?></b><h2><?= $e($params->get('tiktok_handle')) ?></h2><p><?= $e($params->get('tiktok_text')) ?></p><strong><?= $e($params->get('tiktok_link_label')) ?></strong></a>
    <?php endif; ?>
  </div>
</section>
