<?php
/** Administracyjny konfigurator menu VPLO — dostępny tylko dla Super Usera. */
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Session\Session;
use Joomla\CMS\Toolbar\ToolbarHelper;
use Joomla\Database\DatabaseInterface;

$app = Factory::getApplication();
$user = $app->getIdentity();
if (!$user->authorise('core.admin')) {
    throw new RuntimeException('Dostęp wyłącznie dla Super Usera.', 403);
}

ToolbarHelper::title('Konfiguracja menu VPLO', 'wrench');
$db = Factory::getContainer()->get(DatabaseInterface::class);
$menuType = 'mainmenu';
$menuTitle = 'Menu główne PL';
$wanted = ['Aktualności' => 'aktualnosci', 'Szkoła' => 'szkola', 'Uczeń' => 'uczen', 'Edukacja' => 'edukacja', 'Rekrutacja' => 'rekrutacja', 'Galeria' => 'galeria', 'Kontakt' => 'kontakt'];

$inspect = static function () use ($db, $menuType, $menuTitle, $wanted): array {
    $q = $db->getQuery(true)->select('*')->from($db->quoteName('#__menu_types'))->where($db->quoteName('menutype') . ' = ' . $db->quote($menuType));
    $db->setQuery($q); $menu = $db->loadAssoc() ?: null;
    $q = $db->getQuery(true)->select('*')->from($db->quoteName('#__modules'))->where($db->quoteName('module') . ' = ' . $db->quote('mod_menu'))->where($db->quoteName('title') . ' = ' . $db->quote($menuTitle));
    $db->setQuery($q); $module = null;
    foreach ($db->loadAssocList() as $candidate) { $params = json_decode($candidate['params'] ?? '{}', true) ?: []; if (($params['menutype'] ?? '') === $menuType) { $module = $candidate; break; } }
    $q = $db->getQuery(true)->select($db->quoteName(['title', 'id']))->from($db->quoteName('#__menu'))->where($db->quoteName('menutype') . ' = ' . $db->quote($menuType))->where($db->quoteName('parent_id') . ' = 1');
    $db->setQuery($q); $existing = array_column($db->loadAssocList(), 'id', 'title');
    $errors = [];
    if (!$menu || $menu['title'] !== $menuTitle) $errors[] = 'Nie znaleziono menu „Menu główne PL” o typie „mainmenu”.';
    if (!$module) $errors[] = 'Nie znaleziono modułu menu „Menu główne PL” korzystającego z „mainmenu”.';
    if ($module && ((int) $module['published'] !== 1 || (int) $module['showtitle'] !== 0 || $module['position'] !== 'main-menu')) $errors[] = 'Moduł nie ma oczekiwanych ustawień: opublikowany, ukryty tytuł, pozycja main-menu.';
    if ($module) {
        $params = json_decode($module['params'] ?? '{}', true) ?: [];
        if (empty($params['showAllChildren'])) $errors[] = 'Moduł ma wyłączone pokazywanie podmenu.';
        $q = $db->getQuery(true)->select('COUNT(*)')->from($db->quoteName('#__modules_menu'))->where($db->quoteName('moduleid') . ' = ' . (int) $module['id'])->where($db->quoteName('menuid') . ' = 0');
        $db->setQuery($q);
        if (!(int) $db->loadResult()) $errors[] = 'Moduł nie jest przypisany do wszystkich stron.';
    }
    return ['ready' => !$errors, 'errors' => $errors, 'existing' => array_keys($existing), 'missing' => array_values(array_diff(array_keys($wanted), array_keys($existing)))];
};

$task = $app->input->post->getCmd('task');
if ($task === 'preview' || $task === 'apply') {
    Session::checkToken('post') or throw new RuntimeException('Nieprawidłowy token CSRF.', 403);
    $state = $inspect();
    if ($task === 'apply' && $state['ready']) {
        $db->transactionStart(); $created = 0;
        try {
            foreach ($wanted as $title => $alias) {
                if (!in_array($title, $state['missing'], true)) continue;
                $q = $db->getQuery(true)->select($db->quoteName('rgt'))->from($db->quoteName('#__menu'))->where($db->quoteName('id') . ' = 1'); $db->setQuery($q); $right = (int) $db->loadResult();
                if ($right < 1) throw new RuntimeException('Nie odnaleziono korzenia drzewa menu Joomla (ID 1).');
                $q = $db->getQuery(true)->update($db->quoteName('#__menu'))->set($db->quoteName('rgt') . ' = ' . $db->quoteName('rgt') . ' + 2')->where($db->quoteName('id') . ' = 1'); $db->setQuery($q)->execute();
                $columns = ['menutype','title','alias','note','path','link','type','published','parent_id','level','component_id','checked_out','checked_out_time','browserNav','access','img','template_style_id','params','lft','rgt','home','language','client_id'];
                $values = [$db->quote($menuType),$db->quote($title),$db->quote($alias),$db->quote('Tymczasowa pozycja — do powiązania z widokiem Joomla.'),$db->quote($alias),$db->quote(''),$db->quote('heading'),1,1,1,0,0,$db->quote($db->getNullDate()),0,1,$db->quote(''),0,$db->quote('{"menu_show":1}'),$right,$right + 1,0,$db->quote('*'),0];
                $q = $db->getQuery(true)->insert($db->quoteName('#__menu'))->columns($db->quoteName($columns))->values(implode(',', $values)); $db->setQuery($q)->execute(); $created++;
            }
            $db->transactionCommit(); $app->enqueueMessage("Dodano brakujące pozycje: {$created}.", 'message');
        } catch (Throwable $e) { $db->transactionRollback(); $app->enqueueMessage('Nic nie zmieniono: ' . $e->getMessage(), 'error'); }
        $app->redirect(Route::_('index.php?option=com_vplo_setup', false));
    }
    $app->setUserState('com_vplo_setup.preview', $task === 'preview');
}
$state = $inspect(); $preview = (bool) $app->getUserState('com_vplo_setup.preview', false);
?>
<div class="com-vplo-setup">
  <h1>Konfiguracja menu VPLO</h1>
  <p>Mechanizm działa wyłącznie na istniejącym menu <strong>Menu główne PL</strong> (`mainmenu`). Nie tworzy menu, modułu ani nie zmienia strony domyślnej Home.</p>
  <?php if (!$state['ready']) : ?>
    <div class="alert alert-danger"><strong>Zapis zablokowany.</strong><ul><?php foreach ($state['errors'] as $error) : ?><li><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></li><?php endforeach; ?></ul></div>
  <?php else : ?>
    <div class="alert alert-success">Weryfikacja menu i istniejącego modułu przebiegła poprawnie.</div>
  <?php endif; ?>
  <h2>Planowane zmiany</h2>
  <p><?= $state['missing'] ? 'Do dodania: <strong>' . htmlspecialchars(implode(', ', $state['missing']), ENT_QUOTES, 'UTF-8') . '</strong>.' : 'Wszystkie wymagane pozycje już istnieją; zastosowanie zmian nie zapisze danych.' ?></p>
  <p>Już istnieją: <?= $state['existing'] ? htmlspecialchars(implode(', ', $state['existing']), ENT_QUOTES, 'UTF-8') : 'brak' ?>.</p>
  <form method="post" action="<?= Route::_('index.php?option=com_vplo_setup') ?>">
    <button class="btn btn-secondary" name="task" value="preview">Podgląd zmian</button>
    <button class="btn btn-primary" name="task" value="apply" <?= $state['ready'] ? '' : 'disabled' ?> onclick="return confirm('Dodać wyłącznie brakujące pozycje do menu mainmenu?');">Zastosuj zmiany</button>
    <?= HTMLHelper::_('form.token') ?>
  </form>
  <?php if ($preview) : ?><div class="alert alert-info mt-3">To był tylko podgląd — żadne dane nie zostały zapisane.</div><?php endif; ?>
</div>
