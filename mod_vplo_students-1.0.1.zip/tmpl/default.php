<?php
defined('_JEXEC') or die;

$e = static fn ($value): string => htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
$videos = array_map(static fn ($video): array => (array) $video, array_values((array) $params->get('videos', [])));
$videos = array_values(array_filter($videos, static fn (array $video): bool => !empty($video['video_file']) || !empty($video['video_url'])));
if (!$videos) { return; }
?>
<section class="container home-media">
  <?php if ($params->get('heading')) : ?><b><?= $e($params->get('heading')) ?></b><?php endif; ?>
  <?php if ($params->get('intro')) : ?><p><?= nl2br($e($params->get('intro'))) ?></p><?php endif; ?>
  <?php foreach ($videos as $video) : $source = $video['video_file'] ?: $video['video_url']; ?>
    <video controls preload="metadata"<?= !empty($video['poster']) ? ' poster="' . $e($video['poster']) . '"' : '' ?><?= !empty($video['alt']) ? ' aria-label="' . $e($video['alt']) . '"' : '' ?><?= !empty($video['title']) ? ' title="' . $e($video['title']) . '"' : '' ?>><source src="<?= $e($source) ?>" type="video/mp4"></video>
  <?php endforeach; ?>
</section>
